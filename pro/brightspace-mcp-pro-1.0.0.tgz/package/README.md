# Brightspace MCP Pro (private)

Paid edition of the Brightspace MCP server, sold at https://brightspacemcp.com/pro/.
Separate from the free, public `brightspace-d2l-mcp` project, which is not changed by anything here.

- 7-day free trial, then $4 CAD a month (Stripe). Every tool needs an active key.
- Alerts on the student's computer: deadline alerts (24h and 2h), daily digest, grade alerts, live calendar feed.
- Installs from the website, not npm: `npx -y https://brightspacemcp.com/pro/brightspace-mcp-pro.tgz setup --key bmp_...`
  The site's `install.sh` (Mac/Linux) and Windows setup file wrap this.

## Release

```bash
npm ci
npm run pack:site   # builds, tests, writes ../brightspace-mcp-site/pro/*.tgz and version.json
```

Bump `version` in package.json first, then commit the new files in the site repo to deploy.
